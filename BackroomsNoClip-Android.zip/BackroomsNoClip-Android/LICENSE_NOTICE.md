# Aviso de licencia y atribución

Proyecto original: `AgenteMaxo/backrooms-noclip`.

Según el archivo README del repositorio original:

- Código y juego: PolyForm Noncommercial 1.0.0, © 2026 MeltStudio.
- Uso comercial reservado al autor.
- Contenido descriptivo derivado de backrooms.fandom.com bajo CC BY-SA 3.0 y con atribuciones conservadas por el proyecto.
- Three.js r147 bajo licencia MIT.
- Fuentes tipográficas bajo SIL OFL.

Este envoltorio Android no cambia esas condiciones. Antes de distribuir o publicar el APK, revisa y conserva los archivos de licencia del proyecto original.
