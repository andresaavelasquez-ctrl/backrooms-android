# BACKROOMS — No-Clip para Android v1.0.2

Este proyecto convierte el cliente web de `AgenteMaxo/backrooms-noclip` en una aplicación Android con WebView, pantalla completa y orientación horizontal.

## Qué incluye

- Cliente Android nativo sin AndroidX.
- JavaScript, WebGL, Canvas, audio, `localStorage` y WebSocket habilitados.
- Controles táctiles originales del juego forzados en Android.
- Importación de perfiles mediante selector de archivos.
- Exportación de perfiles `data:` a `Descargas/BackroomsNoClip`.
- Soporte para servidores HTTPS/WSS y para HTTP/WS durante pruebas en red local.
- Botón Atrás: envía `Escape`; dos pulsaciones permiten cambiar la URL del servidor.

## Requisito del proyecto actual

La rama `main` es actualmente **BACKROOMS MMO**. El botón de inicio conecta a un servidor WebSocket en `/ws`, por lo que el APK necesita un servidor que ejecute:

```bash
cd server
npm ci --omit=dev
node server.js 8080
```

En una red local, escribe en la app algo como:

```text
http://192.168.1.50:8080
```

Para producción, despliega el servidor detrás de HTTPS y escribe:

```text
https://juego.tudominio.com
```

## Compilar en Android Studio

1. Abre esta carpeta con Android Studio.
2. Usa JDK 17.
3. Espera la sincronización de Gradle.
4. Selecciona **Build > Build APK(s)**.
5. El APK aparece en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar mediante GitHub Actions

Sube esta carpeta a un repositorio de GitHub. El flujo `.github/workflows/build-apk.yml` genera automáticamente un artefacto llamado `backrooms-noclip-debug-apk`.

## Licencia

El envoltorio Android es una adaptación técnica. El código y el contenido del juego original conservan sus propias licencias y atribuciones. El repositorio original declara PolyForm Noncommercial 1.0.0 para el juego y código, además de atribuciones para contenido derivado de la wiki y terceros.


## Corrección v1.0.2

- Conserva las correcciones de inicio seguro de v1.0.1.
- Fuerza la visibilidad de `#touch-controls` mientras la pantalla del juego está activa.
- Observa los cambios de pantalla y vuelve a aplicar los controles cuando el juego modifica clases o estilos.
- Eleva los controles por encima del Canvas/WebGL y restaura eventos táctiles en cada botón.
- Oculta los controles automáticamente en el título y en pantallas que no sean la partida.
- Incluye una firma de depuración estable para que las próximas compilaciones puedan instalarse como actualización sin borrar los datos. Esta clave es solo para pruebas y no debe usarse para publicar en Google Play.
