# Sin reglas adicionales: la aplicación usa exclusivamente APIs de Android.
