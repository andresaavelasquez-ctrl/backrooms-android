package com.agentemaxo.backroomsnoclip;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String PREFS = "backrooms_android";
    private static final String KEY_SERVER_URL = "server_url";
    private static final int FILE_CHOOSER_REQUEST = 4001;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileChooser;
    private long lastBackPress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersiveMode();

        String savedUrl = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_SERVER_URL, "");
        if (savedUrl == null || savedUrl.trim().isEmpty()) {
            showServerScreen("");
        } else {
            openGame(savedUrl);
        }
    }

    private void showServerScreen(String initialValue) {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(24), dp(28), dp(24));
        root.setBackgroundColor(Color.rgb(6, 5, 4));

        TextView title = new TextView(this);
        title.setText("BACKROOMS — NO-CLIP");
        title.setTextColor(Color.rgb(217, 198, 110));
        title.setTextSize(24f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView explanation = new TextView(this);
        explanation.setText("La rama actual es multijugador. Escribe la dirección del servidor que ejecuta server/server.js. El mismo servidor entrega el juego y el WebSocket /ws.");
        explanation.setTextColor(Color.rgb(239, 232, 208));
        explanation.setTextSize(16f);
        explanation.setGravity(Gravity.CENTER);
        explanation.setPadding(0, 0, 0, dp(14));
        root.addView(explanation, new LinearLayout.LayoutParams(
                Math.min(dp(760), getResources().getDisplayMetrics().widthPixels - dp(40)),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        EditText serverInput = new EditText(this);
        serverInput.setSingleLine(true);
        serverInput.setHint(getString(com.agentemaxo.backroomsnoclip.R.string.server_hint));
        serverInput.setText(initialValue);
        serverInput.setTextColor(Color.rgb(239, 232, 208));
        serverInput.setHintTextColor(Color.rgb(138, 132, 112));
        serverInput.setBackgroundColor(Color.rgb(20, 18, 13));
        serverInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                Math.min(dp(700), getResources().getDisplayMetrics().widthPixels - dp(50)),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        inputParams.setMargins(0, 0, 0, dp(14));
        root.addView(serverInput, inputParams);

        Button open = new Button(this);
        open.setText("ABRIR JUEGO");
        open.setTextColor(Color.rgb(6, 5, 4));
        open.setBackgroundColor(Color.rgb(217, 198, 110));
        open.setOnClickListener(v -> {
            String normalized = normalizeServerUrl(serverInput.getText().toString());
            if (normalized.isEmpty()) {
                Toast.makeText(this, "Escribe la URL o IP del servidor.", Toast.LENGTH_LONG).show();
                return;
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_SERVER_URL, normalized).apply();
            openGame(normalized);
        });
        root.addView(open, new LinearLayout.LayoutParams(dp(220), dp(54)));

        TextView note = new TextView(this);
        note.setText("Pruebas locales: http://IP-DE-TU-PC:8080\nProducción: https://tu-dominio.com");
        note.setTextColor(Color.rgb(154, 148, 130));
        note.setTextSize(14f);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(root);
        serverInput.requestFocus();
        enterImmersiveMode();
    }

    private String normalizeServerUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) return "";

        if (value.startsWith("wss://")) value = "https://" + value.substring(6);
        else if (value.startsWith("ws://")) value = "http://" + value.substring(5);
        else if (!value.startsWith("https://") && !value.startsWith("http://")) {
            value = "https://" + value;
        }

        if (value.endsWith("/ws")) value = value.substring(0, value.length() - 3);
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private void openGame(String serverUrl) {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAndroidAdjustments(view);
                enterImmersiveMode();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "No se pudo abrir el servidor. Revisa la URL, la red y el puerto.",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    view.loadUrl(uri.toString());
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    Toast.makeText(MainActivity.this, "No hay una aplicación para abrir ese enlace.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    pendingFileChooser = null;
                    Toast.makeText(MainActivity.this, "No se encontró un selector de archivos.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });

        webView.setDownloadListener(buildDownloadListener());
        setContentView(webView);
        webView.loadUrl(serverUrl);
        webView.requestFocus();
        enterImmersiveMode();
    }

    private void injectAndroidAdjustments(WebView view) {
        String js = "(function(){" +
                "document.documentElement.style.setProperty('--vh',(window.innerHeight*0.01)+'px');" +
                "var s=document.getElementById('android-apk-style');" +
                "if(!s){s=document.createElement('style');s.id='android-apk-style';" +
                "s.textContent='body.game-active #touch-controls{display:flex!important}' +" +
                "'#touch-controls{padding-bottom:max(8px,env(safe-area-inset-bottom))!important}' +" +
                "'.hint{display:none!important} button{-webkit-tap-highlight-color:transparent}';" +
                "document.head.appendChild(s);}" +
                "window.addEventListener('resize',function(){document.documentElement.style.setProperty('--vh',(window.innerHeight*0.01)+'px');});" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    private DownloadListener buildDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url != null && url.startsWith("data:")) {
                try {
                    saveDataUrl(url, contentDisposition, mimeType);
                } catch (Exception ex) {
                    Toast.makeText(this, "No se pudo guardar el archivo exportado.", Toast.LENGTH_LONG).show();
                }
                return;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ex) {
                Toast.makeText(this, "No se pudo abrir la descarga.", Toast.LENGTH_LONG).show();
            }
        };
    }

    private void saveDataUrl(String dataUrl, String contentDisposition, String suppliedMime) throws Exception {
        int comma = dataUrl.indexOf(',');
        if (comma < 0) throw new IllegalArgumentException("data URL inválida");
        String header = dataUrl.substring(5, comma);
        String payload = dataUrl.substring(comma + 1);
        String mime = header.split(";", 2)[0];
        if (mime.isEmpty()) mime = suppliedMime == null ? "application/octet-stream" : suppliedMime;

        byte[] bytes;
        if (header.toLowerCase(Locale.ROOT).contains(";base64")) {
            bytes = android.util.Base64.decode(payload, android.util.Base64.DEFAULT);
        } else {
            bytes = URLDecoder.decode(payload, StandardCharsets.UTF_8.name())
                    .getBytes(StandardCharsets.UTF_8);
        }

        String filename = "backrooms-export-" + System.currentTimeMillis();
        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (extension == null || extension.isEmpty()) extension = mime.contains("json") ? "json" : "bin";
        filename += "." + extension;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BackroomsNoClip");
            Uri target = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (target == null) throw new IllegalStateException("No se pudo crear la descarga");
            try (OutputStream out = getContentResolver().openOutputStream(target)) {
                if (out == null) throw new IllegalStateException("No se pudo abrir la descarga");
                out.write(bytes);
            }
        } else {
            java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = getFilesDir();
            java.io.File target = new java.io.File(dir, filename);
            try (OutputStream out = new java.io.FileOutputStream(target)) {
                out.write(bytes);
            }
        }
        Toast.makeText(this, "Archivo guardado en Descargas/BackroomsNoClip", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileChooser == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        pendingFileChooser.onReceiveValue(result);
        pendingFileChooser = null;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (webView != null && event.getAction() == KeyEvent.ACTION_DOWN &&
                event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            handleBackButton();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void handleBackButton() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 1800) {
            String current = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_SERVER_URL, "");
            showServerScreen(current == null ? "" : current);
            lastBackPress = 0;
            return;
        }
        lastBackPress = now;
        webView.evaluateJavascript(
                "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));", null);
        Toast.makeText(this, "Pulsa Atrás otra vez para cambiar el servidor.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
