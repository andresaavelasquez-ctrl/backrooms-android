package com.agentemaxo.backroomsnoclip;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String PREFS = "backrooms_android";
    private static final String KEY_SERVER_URL = "server_url";
    private static final int FILE_CHOOSER_REQUEST = 4001;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileChooser;
    private long lastBackPress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            safeImmersiveMode();

            String savedUrl = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_SERVER_URL, "");
            if (savedUrl == null || savedUrl.trim().isEmpty()) {
                showServerScreen("");
            } else {
                openGame(savedUrl);
            }
        } catch (Throwable error) {
            showFatalError("La aplicación no pudo iniciar", error);
        }
    }

    private void showServerScreen(String initialValue) {
        destroyWebView();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(6, 5, 4));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(24), dp(28), dp(24));
        root.setBackgroundColor(Color.rgb(6, 5, 4));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("BACKROOMS — NO-CLIP");
        title.setTextColor(Color.rgb(217, 198, 110));
        title.setTextSize(24f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView version = new TextView(this);
        version.setText("Android v1.0.2 — controles táctiles reforzados");
        version.setTextColor(Color.rgb(138, 132, 112));
        version.setTextSize(13f);
        version.setGravity(Gravity.CENTER);
        version.setPadding(0, 0, 0, dp(12));
        root.addView(version);

        TextView explanation = new TextView(this);
        explanation.setText("Escribe la dirección del servidor que ejecuta server/server.js. El servidor entrega el juego y la conexión WebSocket /ws.");
        explanation.setTextColor(Color.rgb(239, 232, 208));
        explanation.setTextSize(16f);
        explanation.setGravity(Gravity.CENTER);
        explanation.setPadding(0, 0, 0, dp(14));
        root.addView(explanation, new LinearLayout.LayoutParams(
                safeWidth(dp(760), dp(40)),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        EditText serverInput = new EditText(this);
        serverInput.setSingleLine(true);
        serverInput.setHint(getString(R.string.server_hint));
        serverInput.setText(initialValue == null ? "" : initialValue);
        serverInput.setTextColor(Color.rgb(239, 232, 208));
        serverInput.setHintTextColor(Color.rgb(138, 132, 112));
        serverInput.setBackgroundColor(Color.rgb(20, 18, 13));
        serverInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                safeWidth(dp(700), dp(50)),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        inputParams.setMargins(0, 0, 0, dp(14));
        root.addView(serverInput, inputParams);

        Button open = new Button(this);
        open.setText("ABRIR JUEGO");
        open.setTextColor(Color.rgb(6, 5, 4));
        open.setBackgroundColor(Color.rgb(217, 198, 110));
        open.setOnClickListener(v -> {
            String normalized = normalizeServerUrl(serverInput.getText().toString());
            if (normalized.isEmpty()) {
                Toast.makeText(this, "Escribe la URL o IP del servidor.", Toast.LENGTH_LONG).show();
                return;
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_SERVER_URL, normalized).apply();
            openGame(normalized);
        });
        root.addView(open, new LinearLayout.LayoutParams(dp(220), dp(54)));

        Button reset = new Button(this);
        reset.setText("BORRAR DIRECCIÓN GUARDADA");
        reset.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_SERVER_URL).apply();
            serverInput.setText("");
            Toast.makeText(this, "Dirección borrada.", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(dp(280), dp(50));
        resetParams.setMargins(0, dp(10), 0, 0);
        root.addView(reset, resetParams);

        TextView note = new TextView(this);
        note.setText("Red local: http://IP-DE-TU-PC:8080\nInternet: https://tu-dominio.com\n\nNo uses localhost en el teléfono.");
        note.setTextColor(Color.rgb(154, 148, 130));
        note.setTextSize(14f);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scroll);
        safeImmersiveMode();
    }

    private int safeWidth(int preferred, int horizontalMargin) {
        int available = getResources().getDisplayMetrics().widthPixels - horizontalMargin;
        return Math.max(dp(220), Math.min(preferred, available));
    }

    private String normalizeServerUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) return "";

        if (value.startsWith("wss://")) value = "https://" + value.substring(6);
        else if (value.startsWith("ws://")) value = "http://" + value.substring(5);
        else if (!value.startsWith("https://") && !value.startsWith("http://")) {
            value = "https://" + value;
        }

        if (value.endsWith("/ws")) value = value.substring(0, value.length() - 3);
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private void openGame(String serverUrl) {
        try {
            destroyWebView();

            WebView.setWebContentsDebuggingEnabled(
                    (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0);

            webView = new WebView(this);
            webView.setBackgroundColor(Color.BLACK);
            webView.setFocusable(true);
            webView.setFocusableInTouchMode(true);

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(true);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            }

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    injectAndroidAdjustments(view);
                    safeImmersiveMode();
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    super.onReceivedError(view, request, error);
                    if (request.isForMainFrame()) {
                        Toast.makeText(MainActivity.this,
                                "No se pudo abrir el servidor. Revisa la URL, la red y el puerto.",
                                Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    String scheme = uri.getScheme();
                    if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                        view.loadUrl(uri.toString());
                        return true;
                    }
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        Toast.makeText(MainActivity.this,
                                "No hay una aplicación para abrir ese enlace.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
            });

            webView.setWebChromeClient(new WebChromeClient() {
                @Override
                public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                                 FileChooserParams fileChooserParams) {
                    if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = filePathCallback;
                    try {
                        Intent intent = fileChooserParams.createIntent();
                        startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (ActivityNotFoundException ex) {
                        pendingFileChooser = null;
                        Toast.makeText(MainActivity.this,
                                "No se encontró un selector de archivos.", Toast.LENGTH_LONG).show();
                        return false;
                    }
                }

                @Override
                public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage(message)
                            .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                            .setOnCancelListener(dialog -> result.cancel())
                            .show();
                    return true;
                }
            });

            webView.setDownloadListener(buildDownloadListener());
            setContentView(webView);
            webView.loadUrl(serverUrl);
            webView.requestFocus();
            safeImmersiveMode();
        } catch (Throwable error) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_SERVER_URL).apply();
            showFatalError("No se pudo iniciar Android System WebView", error);
        }
    }

    private void showFatalError(String titleText, Throwable error) {
        destroyWebView();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(6, 5, 4));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(Color.rgb(201, 74, 58));
        title.setTextSize(22f);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        String message = error == null ? "Error desconocido" :
                error.getClass().getName() + "\n\n" + String.valueOf(error.getMessage());
        TextView details = new TextView(this);
        details.setText(message);
        details.setTextColor(Color.WHITE);
        details.setTextSize(14f);
        details.setTextIsSelectable(true);
        details.setPadding(0, dp(16), 0, dp(16));
        root.addView(details, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Button retry = new Button(this);
        retry.setText("VOLVER A CONFIGURAR");
        retry.setOnClickListener(v -> showServerScreen(""));
        root.addView(retry, new LinearLayout.LayoutParams(dp(250), dp(54)));

        TextView help = new TextView(this);
        help.setText("Actualiza Android System WebView y Google Chrome desde Play Store. Después reinicia el teléfono y vuelve a intentarlo. Si aparece este mensaje otra vez, toma una captura completa.");
        help.setTextColor(Color.rgb(217, 198, 110));
        help.setTextSize(14f);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(16), 0, 0);
        root.addView(help);

        setContentView(scroll);
        safeImmersiveMode();
    }

    private void injectAndroidAdjustments(WebView view) {
        String js = "(function(){" +
                "function setImp(el,p,v){if(!el)return;" +
                "if(el.style.getPropertyValue(p)!==v||el.style.getPropertyPriority(p)!=='important')" +
                "el.style.setProperty(p,v,'important');}" +
                "function gameVisible(){var g=document.getElementById('screen-game');" +
                "if(!g)return false;var c=getComputedStyle(g);" +
                "return c.display!=='none'&&c.visibility!=='hidden'&&c.opacity!=='0';}" +
                "function apply(){" +
                "document.documentElement.style.setProperty('--vh',(window.innerHeight*0.01)+'px');" +
                "var c=document.getElementById('touch-controls');if(!c)return;" +
                "var on=gameVisible();" +
                "setImp(c,'display',on?'flex':'none');" +
                "setImp(c,'visibility',on?'visible':'hidden');" +
                "setImp(c,'opacity',on?'1':'0');" +
                "setImp(c,'position','fixed');setImp(c,'left','0');setImp(c,'right','0');" +
                "setImp(c,'bottom','max(10px, env(safe-area-inset-bottom))');" +
                "setImp(c,'z-index','2147483000');setImp(c,'pointer-events','none');" +
                "setImp(c,'justify-content','space-between');setImp(c,'align-items','flex-end');" +
                "c.querySelectorAll('button').forEach(function(b){" +
                "setImp(b,'display','block');setImp(b,'visibility','visible');" +
                "setImp(b,'opacity','1');setImp(b,'pointer-events','auto');" +
                "setImp(b,'touch-action','none');setImp(b,'min-width','52px');" +
                "setImp(b,'min-height','48px');});" +
                "var d=c.querySelector('.touch-dpad');var a=c.querySelector('.touch-actions');" +
                "if(d){setImp(d,'display','grid');setImp(d,'pointer-events','none');}" +
                "if(a){setImp(a,'display','grid');setImp(a,'pointer-events','none');}" +
                "}" +
                "var scheduled=false;function schedule(){if(scheduled)return;scheduled=true;" +
                "requestAnimationFrame(function(){scheduled=false;apply();});}" +
                "if(!document.getElementById('android-apk-style')){" +
                "var s=document.createElement('style');s.id='android-apk-style';" +
                "s.textContent='#touch-controls{padding:0 max(14px,env(safe-area-inset-right)) max(8px,env(safe-area-inset-bottom)) max(14px,env(safe-area-inset-left))!important}' +" +
                "'#touch-controls button{-webkit-tap-highlight-color:transparent!important;user-select:none!important;-webkit-user-select:none!important}' +" +
                "'.hint{display:none!important}';document.head.appendChild(s);}" +
                "window.__backroomsAndroidTouchFix=apply;" +
                "new MutationObserver(schedule).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','style']});" +
                "window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);" +
                "window.addEventListener('pageshow',schedule);" +
                "[0,150,400,800,1500,3000,6000].forEach(function(ms){setTimeout(schedule,ms);});" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    private DownloadListener buildDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url != null && url.startsWith("data:")) {
                try {
                    saveDataUrl(url, mimeType);
                } catch (Exception ex) {
                    Toast.makeText(this, "No se pudo guardar el archivo exportado.", Toast.LENGTH_LONG).show();
                }
                return;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ex) {
                Toast.makeText(this, "No se pudo abrir la descarga.", Toast.LENGTH_LONG).show();
            }
        };
    }

    private void saveDataUrl(String dataUrl, String suppliedMime) throws Exception {
        int comma = dataUrl.indexOf(',');
        if (comma < 0) throw new IllegalArgumentException("data URL inválida");
        String header = dataUrl.substring(5, comma);
        String payload = dataUrl.substring(comma + 1);
        String mime = header.split(";", 2)[0];
        if (mime.isEmpty()) mime = suppliedMime == null ? "application/octet-stream" : suppliedMime;

        byte[] bytes;
        if (header.toLowerCase(Locale.ROOT).contains(";base64")) {
            bytes = android.util.Base64.decode(payload, android.util.Base64.DEFAULT);
        } else {
            bytes = URLDecoder.decode(payload, StandardCharsets.UTF_8.name())
                    .getBytes(StandardCharsets.UTF_8);
        }

        String filename = "backrooms-export-" + System.currentTimeMillis();
        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (extension == null || extension.isEmpty()) extension = mime.contains("json") ? "json" : "bin";
        filename += "." + extension;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/BackroomsNoClip");
            Uri target = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (target == null) throw new IllegalStateException("No se pudo crear la descarga");
            try (OutputStream out = getContentResolver().openOutputStream(target)) {
                if (out == null) throw new IllegalStateException("No se pudo abrir la descarga");
                out.write(bytes);
            }
        } else {
            java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = getFilesDir();
            java.io.File target = new java.io.File(dir, filename);
            try (OutputStream out = new java.io.FileOutputStream(target)) {
                out.write(bytes);
            }
        }
        Toast.makeText(this, "Archivo guardado en Descargas/BackroomsNoClip", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileChooser == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) {
                    result[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        pendingFileChooser.onReceiveValue(result);
        pendingFileChooser = null;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (webView != null && event.getAction() == KeyEvent.ACTION_DOWN &&
                event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            handleBackButton();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void handleBackButton() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 1800) {
            String current = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_SERVER_URL, "");
            showServerScreen(current == null ? "" : current);
            lastBackPress = 0;
            return;
        }
        lastBackPress = now;
        if (webView != null) {
            webView.evaluateJavascript(
                    "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));",
                    null);
        }
        Toast.makeText(this, "Pulsa Atrás otra vez para cambiar el servidor.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        safeImmersiveMode();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        destroyWebView();
        super.onDestroy();
    }

    private void destroyWebView() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.loadUrl("about:blank");
                webView.clearHistory();
                webView.removeAllViews();
                webView.destroy();
            } catch (Throwable ignored) {
                // Evita que un WebView dañado cierre también la pantalla de recuperación.
            }
            webView = null;
        }
    }

    private void safeImmersiveMode() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowInsetsController controller = getWindow().getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                                View.SYSTEM_UI_FLAG_FULLSCREEN |
                                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (Throwable ignored) {
            // La pantalla debe seguir abriendo aunque el fabricante cambie el manejo de barras.
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
