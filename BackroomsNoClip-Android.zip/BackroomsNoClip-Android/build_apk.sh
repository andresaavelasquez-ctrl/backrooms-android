#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle no está instalado. Abre el proyecto en Android Studio o usa GitHub Actions." >&2
  exit 1
fi
gradle --no-daemon :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
